-- RECIPE 10 ********************************************
-- How to do it ****************************************

-- Step 2 **********************************************

SELECT ST_Extent(the_geom) FROM chp01.countries WHERE name = 'Italy';